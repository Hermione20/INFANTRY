#ifndef __DELAY_H__
#define __DELAY_H__
#include "public.h"
void delay_ms(unsigned int t);
void delay_us(unsigned int t);
void Delay_ms(unsigned int t);
void Delay_us(unsigned int t);

#endif 

#ifndef __INFANTRY_MODE_SWITCH_TASK_H
#define __INFANTRY_MODE_SWITCH_TASK_H
#include "public.h"



/*************************************************/
#define HIGH_SPEED 1600
#define NORMAL_SPEED 800





void infantry_mode_switch_task(void);


extern chassis_t chassis;











#endif

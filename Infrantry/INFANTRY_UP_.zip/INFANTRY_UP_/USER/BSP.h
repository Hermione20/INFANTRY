#ifndef __BSP_H
#define __BSP_H
#include "public.h"



void BSP_Init(void);

float convert_ecd_angle_to__pi_pi(double ecd_angle,float __pi_pi_angle);
float convert_ecd_angle_to_0_2pi(double ecd_angle,float _0_2pi_angle);











#endif


#include "main.h"


int main()
{

   BSP_Init();
	control_task_Init();
	 
	
	while(1)
	{
		

	}
}
